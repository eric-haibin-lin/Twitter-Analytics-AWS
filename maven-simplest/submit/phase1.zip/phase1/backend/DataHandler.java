package io.vertx.example;

/**
 * Created by Eric Haibin Lin on 28/10/15.
 */
public interface DataHandler {
  String getQuery2(String userId, String tweetTime);
}
