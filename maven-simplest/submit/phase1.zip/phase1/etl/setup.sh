# sudo apt-get -f install python-pip
# sudo yum install python-pip
sudo pip install happybase
python -c 'import happybase'
/home/hadoop/hbase/bin/hbase-daemon.sh start thrift